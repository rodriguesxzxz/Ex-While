package ex3while;
import java.util.Scanner;
public class Ex3While {
    public static void main(String[] args) {
  Scanner ex = new Scanner(System.in);

        System.out.print("Digite um número inteiro: ");
        int limite = ex.nextInt();

        int valor = 1;

        while (valor <= limite) {
            System.out.println(valor);
            valor = valor * 2;
        }

        ex.close();
    }
}