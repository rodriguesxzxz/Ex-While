package ex5;
import java.util.Scanner;
public class Ex5 {
public static void main(String[] args) {
 Scanner ex = new Scanner(System.in); 
int numero = 5;
int contador = 1;
while (contador <= 10) {
int resultado = numero * contador;
 System.out.println(numero + " x " + contador + " = " + resultado);
contador++;
        }s
ex.close();
    }
}