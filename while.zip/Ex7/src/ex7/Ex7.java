package ex7;
import java.util.Scanner;
public class Ex7 {
public static void main(String[] args) {
Scanner ideal = new Scanner(System.in);
int contador = 1;
int dentroPesoIdeal = 0;
while (contador <= 10) {
System.out.println("Pessoa " + contador);
System.out.print("Digite o peso (kg): ");
double peso = ideal.nextDouble();
System.out.print("Digite a altura (m): ");
double altura = ideal.nextDouble();
double imc = peso / (altura * altura);
System.out.println("IMC = " + imc);
if (imc >= 18.5 && imc <= 24.9) {
dentroPesoIdeal++;
            }
contador++;
System.out.println("----------------------");
        }
System.out.println("Quantidade de pessoas com IMC entre 18,5 e 24,9: " + dentroPesoIdeal);
ideal.close();
    }
}
