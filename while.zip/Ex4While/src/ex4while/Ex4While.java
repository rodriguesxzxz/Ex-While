package ex4while;
import java.util.Scanner;
public class Ex4While {
public static void main(String[] args) {
 Scanner met = new Scanner(System.in); 
int numero = 10;
while (numero <= 20) {
double metade = numero / 2.0;
System.out.println("A metade de " + numero + " é " + metade);
 numero++;
        }
        met.close();
    }
}