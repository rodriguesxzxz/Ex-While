
package ex1while;

import java.util.Scanner;

public class Ex1While {

 public static void main(String[] args) {
 Scanner cont = new Scanner(System.in);

        System.out.print("Digite o número inicial: ");
        int inicio = cont.nextInt();

        System.out.print("Digite o número final: ");
        int fim = cont.nextInt();

        while (inicio <= fim) {
            System.out.println(inicio);
            inicio++;
        }

        cont.close();
    }
}
    
    

