package ex8;
import java.util.Scanner;
public class Ex8 {
public static void main(String[] args) {
  Scanner escola = new Scanner(System.in);
        int aluno = 1;
        while (aluno <= 5) {
            double nota1, nota2;
            do {
                System.out.print("Digite a 1ª nota do aluno " + aluno + " (0 a 10): ");
                nota1 = escola.nextDouble();
            } while (nota1 < 0 || nota1 > 10);
            do {
                System.out.print("Digite a 2ª nota do aluno " + aluno + " (0 a 10): ");
                nota2 = escola.nextDouble();
            } while (nota2 < 0 || nota2 > 10);
            double media = (nota1 + nota2) / 2;
            System.out.println("Média do aluno " + aluno + ": " + media);
            System.out.println("---------------------------");
            aluno++;
        }
        escola.close();
    }
}