package ex9;
import java.util.Scanner;
public class Ex9 {
public static void main(String[] args) {
Scanner lanche = new Scanner(System.in);
int codigo, quantidade;
 double totalCompra = 0;
char continuar;
 do {
System.out.println("Cardápio:");
System.out.println("100 - Cachorro quente - R$ 1.20");
System.out.println("101 - Bauru Simples - R$ 1.30");
System.out.println("102 - Bauru com ovo - R$ 1.50");
System.out.println("103 - Hambúrguer - R$ 1.20");
System.out.println("104 - Cheeseburguer - R$ 1.30");
System.out.println("105 - Refrigerante - R$ 1.00");
System.out.print("Digite o código do produto: ");
codigo = lanche.nextInt();
System.out.print("Digite a quantidade: ");
            quantidade = lanche.nextInt();
            double preco = 0;
            switch (codigo) {
                case 100:
                    preco = 1.20;
                    break;
                case 101:
                    preco = 1.30;
                    break;
                case 102:
                    preco = 1.50;
                    break;
                case 103:
                    preco = 1.20;
                    break;
                case 104:
                    preco = 1.30;
                    break;
                case 105:
                    preco = 1.00;
                    break;
                default:
System.out.println("Código inválido!");
preco = 0;
            }
double totalProduto = preco * quantidade;
totalCompra += totalProduto;
System.out.println("Total deste produto: R$ " + totalProduto);
System.out.print("Deseja continuar comprando? (s/n): ");
continuar = lanche.next().charAt(0);
System.out.println("---------------------------");
        } while (continuar == 's' || continuar == 'S');
System.out.println("Total da compra: R$ " + totalCompra);
lanche.close();
    }
}
    