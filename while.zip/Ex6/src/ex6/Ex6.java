package ex6;
import java.util.Scanner;
public class Ex6 {
public static void main(String[] args) {
 Scanner ex6 = new Scanner(System.in);
int contador = 1;
int numero;
int menor = 0;
while (contador <= 10) {
System.out.print("Digite o " + contador + "º número: ");
numero = ex6.nextInt();
 if (contador == 1) {
 menor = numero; 
            } else {
if (numero < menor) {
menor = numero;
                }
            }
contador++;
        }
System.out.println("O menor número é: " + menor);
        ex6.close();
    }
}